Compile by typing:
make
into the terminal.

Run it by typing:
java Main
in the terminal.